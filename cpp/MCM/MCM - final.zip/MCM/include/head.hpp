// Copyright MCM
#ifndef HEAD_H
#define HEAD_H

#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <vector>

#endif  // HEAD_H
