import pandas as pd
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import roc_auc_score, precision_recall_curve
import matplotlib.pyplot as plt
import shap
import os

# ======================
# 解决中文显示问题
# ======================
plt.rcParams["font.sans-serif"] = ["SimHei"]  # 设置中文字体
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示问题


# ======================
# 0. 文件路径配置
# ======================
path = "D:\\PrecticeContest\\cpp\\MCM\\data\\all_country.csv"
if not os.path.exists(path):
    raise FileNotFoundError(f"数据文件未找到: {path}")
# ======================
# 1. 数据加载与验证
# ======================
try:
    data = pd.read_csv(
        path,
        header=None,
        names=[
            "国家",
            "年份",
            "金牌",
            "银牌",
            "铜牌",
            "总获奖",
            "参赛人数",
            "历年参赛次数",
            "总项目数",
            "新增项目数",
            "是否首次获奖",
        ],
        dtype={
            "国家": "category",
            "年份": int,
            "金牌": int,
            "银牌": int,
            "铜牌": int,
            "总获奖": int,
            "参赛人数": int,
            "历年参赛次数": int,
            "总项目数": int,
            "新增项目数": int,
            "是否首次获奖": int,
        },
    )
except Exception as e:
    print(f"数据加载失败: {str(e)}")
    exit()


# ======================
# 2. 数据预处理（增强版）
# ======================
def filter_post_win_data(group):
    """过滤获奖国家后续数据，并记录获奖国家名单"""
    global has_win_countries
    if group["是否首次获奖"].sum() > 0:
        # 记录该国家为已获奖
        has_win_countries.add(group.name)
        # 找到首次获奖年份
        first_win_year = group[group["是否首次获奖"] == 1]["年份"].min()
        return group[group["年份"] <= first_win_year]
    return group


# 初始化已获奖国家集合
has_win_countries = set()

# 应用过滤并记录已获奖国家
data = data.groupby("国家", group_keys=False).apply(filter_post_win_data)

# print(f"\n[已过滤的获奖国家列表]\n{has_win_countries}")


def create_features(df):
    """特征工程"""
    df = df.sort_values(["国家", "年份"])

    # 时间特征
    df["动态参赛次数"] = df.groupby("国家").cumcount() + 1
    df["距首次参赛年数"] = df["年份"] - df.groupby("国家")["年份"].transform("min")

    # 资源分配特征
    df["人均项目参与度"] = df["参赛人数"] / df["总项目数"].replace(0, 1)
    df["项目扩张率"] = df["新增项目数"] / df["总项目数"].shift(1).replace(0, 1)

    # 滞后特征
    for lag in [1, 2, 3]:
        df[f"参赛人数_lag{lag}"] = df.groupby("国家")["参赛人数"].shift(lag)
        df[f"新增项目数_lag{lag}"] = df.groupby("国家")["新增项目数"].shift(lag)

    return df


data_fe = create_features(data).dropna()

# ======================
# 3. 特征选择
# ======================
non_features = ["国家", "年份", "金牌", "银牌", "铜牌", "总获奖", "历年参赛次数"]
features = [
    col for col in data_fe.columns if col not in non_features and col != "是否首次获奖"
]
y = data_fe["是否首次获奖"]  # 正确定义目标变量

print("\n[特征列表]")
print(features)

# ======================
# 4. 时间序列交叉验证
# ======================
tss = TimeSeriesSplit(n_splits=5)
model = HistGradientBoostingClassifier(
    max_iter=300, class_weight={1: 15, 0: 1}, random_state=2023
)

print("\n[交叉验证结果]")
for fold, (train_idx, test_idx) in enumerate(tss.split(data_fe)):
    X_train, X_test = (
        data_fe.iloc[train_idx][features],
        data_fe.iloc[test_idx][features],
    )
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

    model.fit(X_train, y_train)
    proba = model.predict_proba(X_test)[:, 1]
    auc = roc_auc_score(y_test, proba)
    print(f"Fold {fold+1} AUC: {auc:.3f}")

# ======================
# 5. 全量数据训练
# ======================
model_full = model.fit(data_fe[features], y)


# ======================
# 6. 预测2028年
# ======================
def predict_2028_features(country_group):
    """生成2028年特征预测"""
    latest = country_group.iloc[-1].copy()
    latest["年份"] = 2028

    # 基础特征预测
    latest["动态参赛次数"] += 1
    latest["距首次参赛年数"] += 1
    latest["参赛人数"] = int(latest["参赛人数"] * 1.1)
    latest["总项目数"] = int(latest["总项目数"] * 1.05)
    latest["新增项目数"] = int(latest["总项目数"] * 0.2)

    # 更新衍生特征
    latest["人均项目参与度"] = latest["参赛人数"] / latest["总项目数"]
    latest["项目扩张率"] = latest["新增项目数"] / country_group["总项目数"].iloc[-1]

    # 更新滞后特征
    for lag in [1, 2, 3]:
        if f"参赛人数_lag{lag}" in latest:
            valid_idx = -lag - 1 if len(country_group) > lag else 0
            latest[f"参赛人数_lag{lag}"] = country_group["参赛人数"].iloc[valid_idx]
            latest[f"新增项目数_lag{lag}"] = country_group["新增项目数"].iloc[valid_idx]

    return latest


future_data = []
for country in data_fe["国家"].unique():
    # 关键修改：跳过已获奖国家
    if country in has_win_countries:
        print(f"已跳过已获奖国家: {country}")
        continue

    country_df = data_fe[data_fe["国家"] == country]
    if (2028 - country_df["年份"].max()) > 4:
        continue

    try:
        future_row = predict_2028_features(country_df)
        future_data.append(future_row)
    except Exception as e:
        print(f"生成{country}预测失败: {str(e)}")

future_df = pd.DataFrame(future_data).dropna(subset=features)
future_df["预测概率"] = model_full.predict_proba(future_df[features])[:, 1]

# ======================
# 7. 结果输出
# ======================
# 保存结果
output_path = os.path.join(os.path.dirname(path), "prediction_2028.csv")
future_df[["国家", "年份", "预测概率"] + features].to_csv(output_path, index=False)
print(f"\n预测结果已保存至: {output_path}")

# 可视化特征重要性
explainer = shap.Explainer(model_full)
shap_values = explainer(data_fe[features])

plt.figure(figsize=(12, 6))
shap.summary_plot(shap_values, data_fe[features], plot_type="bar", max_display=10)
plt.title("特征重要性（SHAP值）")
plt.tight_layout()
plt.savefig(os.path.join(os.path.dirname(path), "shap_importance.png"))
print("特征重要性图已保存")

# 预测不确定性分析
bootstrap_probas = []
for _ in range(1000):
    sample_idx = np.random.choice(len(data_fe), size=len(data_fe), replace=True)
    model_bs = HistGradientBoostingClassifier(max_iter=300).fit(
        data_fe.iloc[sample_idx][features], y.iloc[sample_idx]
    )
    bootstrap_probas.append(model_bs.predict_proba(future_df[features])[:, 1])

future_df["概率下限"] = np.percentile(bootstrap_probas, 2.5, axis=0)
future_df["概率上限"] = np.percentile(bootstrap_probas, 97.5, axis=0)

print("\n最终预测结果:")
print(
    future_df[["国家", "预测概率", "概率下限", "概率上限"]].sort_values(
        "预测概率", ascending=False
    )
)
